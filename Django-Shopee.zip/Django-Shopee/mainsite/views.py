from django.http import HttpResponse
from datetime import datetime
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .scrapy import Shopee
import time
# Create your views here.


def tv(request,tvno = 0):
	tv_list = [{'name':'蝦皮購物','tvcode':'B19V7kYGAcU'},
				{'name':'蝦皮日常','tvcode':'RnezTOmNelI'},
				{'name':'Shopee Singapore','tvcode':'OOU4FGfmHDo'},]
	now = datetime.now()
	tvno = tvno
	tv = tv_list[tvno]
	return render(request,'boardbase.html',locals())





@login_required(login_url='register')
def index(request):
	q = request.POST.get('q')
	n = request.POST.get('n')
	w = request.POST.get('w')


	shopee = Shopee(q, n, w)

	context={"infos":shopee.scrape()}
	return render(request, "index.html", context)


import urllib.request as req
import requests
import json
import time,os
import datetime 
import bs4


class Website():
	def __init__(self, q, n, w):
		self.q = q
		self.n = n
		self.w = w
	

	def scrape(self):
		pass

class Shopee(Website):
	

	def scrape(self):
		result=[]
		if self.q:
			url_shopee = (f'https://shopee-flask-heroku.herokuapp.com/shopee?q={self.q}&n={self.n}&w={self.w}')
			res =requests.get(url_shopee,)
			soup = bs4.BeautifulSoup(res.text , 'html.parser')
			smt = json.loads(soup.text)
			author = smt[0]['author']
			content = smt[0]['content']
			img = smt[0]['img']
			good = smt[0]['good']
			comment = smt[0]['comment']

			result.append(dict(author=author,content=content,img=img,good=good,comment=comment))
		return result
		print(result)